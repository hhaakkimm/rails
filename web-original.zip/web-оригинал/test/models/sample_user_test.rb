require 'test_helper'

class SampleUserTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
