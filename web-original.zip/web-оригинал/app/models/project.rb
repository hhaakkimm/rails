class Project < ApplicationRecord
  belongs_to :user
end
